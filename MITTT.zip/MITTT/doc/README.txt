We use the package "minted" to display the code of the Instruction Memory Set in the report. 
"minted" uses Pygments of Python for the fancy coloring schemes. You need to invoke the "-shell-escape" 
option in order for LaTeX to allow Pygments to be used.

In TeXStudio, click on the following menu

Options > Configure TeXStudio > Commands

and change:      
pdflatex -synctex=1 -interaction=nonstopmode %.tex

into:      
pdflatex -synctex=1 -interaction=nonstopmode --shell-escape %.tex



To install Pygments, given Python is installed on your machine, simply run the following line on cmd:
pip install Pygments

